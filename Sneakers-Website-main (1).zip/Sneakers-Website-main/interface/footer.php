<html>

<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>


<body>

    <footer>
        <div class="footer_wrapper">

            <div class="footer_social_wrapper footer_content">
              
            <div class="footer_contact footer_content">
                <h3>CONTACT US</h3>
                <br>
                <ul>
                <form action="mailto:sneakers@gmail.com" method="get" >    
                <li>
                <button class="mail_btn">
                <a href="#" class="contact_info">
                            <span class="icon_contact"><i class="fas fa-envelope footer_icon"></i></span>
                            <span class="contact_text">sneakers@gmail.com</span>
                        </a>
                        </button>
                    </li>
                        
                </form> 

                    <li><a href="https://www.facebook.com/" class="contact_info">
                            <span class="icon_contact"> <i class="fa fa-facebook-f footer_icon"></i></span>
                            <span class="contact_text">SNEAKERS</span>
                        </a></li>
                    <li><a href="https://www.instagram.com/" class="contact_info">
                            <span class="icon_contact"> <i class="fa fa-instagram footer_icon"></i></span>
                            <span class="contact_text">@sneakers</span>
                        </a></li>
                </ul>
            </div>


        </div>

    </footer>



  

</body>


</html>