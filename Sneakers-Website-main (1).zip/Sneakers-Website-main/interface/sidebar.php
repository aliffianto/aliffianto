<div id="sidebar" class="sidebar">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
        <a href="index.php">Home</a>
        <a href="productfilter.php?gender=all&category=all&brand=all&sort=all&releasedate=">Shop</a>
        <a href="faq.php">FAQ</a>
        <a href="aboutus.php">About Us</a>
        <a href="contactus.php">Contact Us</a>
        <a href="admin.php">Admin</a>
    </div>