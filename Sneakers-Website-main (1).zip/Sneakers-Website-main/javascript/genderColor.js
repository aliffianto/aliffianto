// const HOME_PANEL = document.getElementById("logo_wrapper")
// const gender = document.getElementById("gender").value
// // console.log(gender)
 
//     const backgroundImage = gender=='m' ? 
//     "grey" 
//     : "pink"
//     HOME_PANEL.style.backgroundColor = backgroundImage
//     // storeBackgroundColor(backgroundImage, SLIDER.checked)
